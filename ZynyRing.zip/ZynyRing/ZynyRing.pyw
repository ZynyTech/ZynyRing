# ==============================================================================
# ZYNYTECH'S ACTIONS CONFIGURATION:
# Customize your buttons, apps, or shortcuts in the 'ACTIONS' list below.
# - 'icon': Path to the icon image displayed in the sector.
# - 'type': 'app' to launch a program, or 'key' for a shortcut.
# - 'cmd': Path to the file (.lnk or .exe) OR key combination (e.g., 'ctrl+c').
# - 'target_app': Required active window ('Altijd' or e.g., 'SLDWORKS.exe').
# - 'is_spotify': True if this is the Spotify button (enables sub-actions).
# ==============================================================================

import sys
import math
import subprocess
import os
import time
import asyncio
import threading

from PyQt6.QtCore import Qt, QPointF, pyqtSignal, QObject, QPropertyAnimation, QEasingCurve, pyqtProperty, QTimer
from PyQt6.QtWidgets import QApplication, QWidget
from PyQt6.QtGui import QPainter, QColor, QPen, QPixmap, QPainterPath, QCursor, QFont, QLinearGradient, QRadialGradient

from pynput import mouse, keyboard
from pynput.mouse import Button
from pynput.keyboard import Key

import win32gui
import win32process
import win32api
import win32con

from comtypes import CLSCTX_ALL, CoCreateInstance
from comtypes.GUID import GUID
from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume, IMMDeviceEnumerator

try:
    from winsdk.windows.media.control import GlobalSystemMediaTransportControlsSessionManager as MediaManager
    from winsdk.windows.storage.streams import DataReader, Buffer, InputStreamOptions
    WINSDK_AVAILABLE = True
except ImportError:
    WINSDK_AVAILABLE = False

keyboard_controller = keyboard.Controller()

CLSID_MMDeviceEnumerator = GUID('{BCDE0395-E52F-467C-8E3D-C4579291692E}')

def get_volume_interface():
    try:
        enumerator = CoCreateInstance(CLSID_MMDeviceEnumerator, IMMDeviceEnumerator, CLSCTX_ALL)
        device = enumerator.GetDefaultAudioEndpoint(0, 1)
        interface = device.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
        return interface.QueryInterface(IAudioEndpointVolume)
    except Exception:
        try:
            devices = AudioUtilities.GetSpeakers()
            interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
            return interface.QueryInterface(IAudioEndpointVolume)
        except Exception:
            return None

volume_control = get_volume_interface()

async def send_media_command_async(cmd):
    if WINSDK_AVAILABLE:
        try:
            manager = await MediaManager.request_async()
            session = manager.get_current_session()
            if session:
                if cmd == "media_play_pause":
                    await session.try_toggle_play_pause_async()
                elif cmd == "media_next":
                    await session.try_skip_next_async()
                elif cmd == "media_previous":
                    await session.try_skip_previous_async()
                return True
        except Exception:
            pass
    return False

def execute_media_command(cmd):
    def worker():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        success = loop.run_until_complete(send_media_command_async(cmd))
        loop.close()
        
        if not success:
            VK_MEDIA_NEXT = 0xB0
            VK_MEDIA_PREV = 0xB1
            VK_MEDIA_PLAY_PAUSE = 0xB3
            
            target_key = None
            if cmd == "media_play_pause":
                target_key = VK_MEDIA_PLAY_PAUSE
            elif cmd == "media_next":
                target_key = VK_MEDIA_NEXT
            elif cmd == "media_previous":
                target_key = VK_MEDIA_PREV
                
            if target_key:
                win32api.keybd_event(target_key, 0, 0, 0)
                win32api.keybd_event(target_key, 0, win32con.KEYEVENTF_KEYUP, 0)

    threading.Thread(target=worker, daemon=True).start()

async def fetch_media_info_async():
    if not WINSDK_AVAILABLE:
        return None, ""
    try:
        manager = await MediaManager.request_async()
        session = manager.get_current_session()
        if not session:
            return None, ""

        media_properties = await session.try_get_media_properties_async()
        title = media_properties.title or ""
        thumbnail_ref = media_properties.thumbnail

        pixmap = None
        if thumbnail_ref:
            stream = await thumbnail_ref.open_read_async()
            size = stream.size
            if size > 0:
                buffer = Buffer(size)
                await stream.read_async(buffer, size, InputStreamOptions.NONE)
                reader = DataReader.from_buffer(buffer)
                byte_array = bytearray(size)
                reader.read_bytes(byte_array)
                
                pixmap = QPixmap()
                pixmap.loadFromData(byte_array)

        return pixmap, title
    except Exception:
        return None, ""

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

ACTIONS = [
    {"label": "", "icon": os.path.join(SCRIPT_DIR, "solidworks.png"), "type": "key", "cmd": "f21",                                               "target_app": "Altijd"},
    {"label": "", "icon": os.path.join(SCRIPT_DIR, "spotify.png"),    "type": "app", "cmd": r"C:\Users\MauriceStoop\Desktop\Spotify.lnk",       "target_app": "Altijd", "is_spotify": True},
    {"label": "", "icon": os.path.join(SCRIPT_DIR, "copy.png"),       "type": "key", "cmd": "ctrl+c",                                            "target_app": "Altijd"},
    {"label": "", "icon": os.path.join(SCRIPT_DIR, "paste.png"),      "type": "key", "cmd": "ctrl+v",                                            "target_app": "Altijd"},
    {"label": "", "icon": os.path.join(SCRIPT_DIR, "dimension.png"),  "type": "key", "cmd": "d",                                                 "target_app": "SLDWORKS.exe"},
]

MUSIC_SUB_ACTIONS = [
    {"label": "⏭", "cmd": "media_next"},
    {"label": "⏯", "cmd": "media_play_pause"},
    {"label": "⏮", "cmd": "media_previous"},
]

def get_active_window_exe():
    try:
        hwnd = win32gui.GetForegroundWindow()
        if not hwnd:
            return ""
        _, pid = win32process.GetWindowThreadProcessId(hwnd)
        handle = win32api.OpenProcess(win32con.PROCESS_QUERY_INFORMATION | win32con.PROCESS_VM_READ, False, pid)
        exe_path = win32process.GetModuleFileNameEx(handle, 0)
        win32api.CloseHandle(handle)
        return os.path.basename(exe_path)
    except Exception:
        return ""

class MenuSignals(QObject):
    show_menu = pyqtSignal()
    hide_menu = pyqtSignal()
    change_volume = pyqtSignal(int)
    handle_click = pyqtSignal()
    media_loaded = pyqtSignal(object, str)

class RadialMenu(QWidget):
    def __init__(self, signals):
        super().__init__()
        self.signals = signals

        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint | 
            Qt.WindowType.WindowStaysOnTopHint | 
            Qt.WindowType.Tool |
            Qt.WindowType.WindowDoesNotAcceptFocus
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setStyleSheet("background: transparent;")
        self.resize(600, 600)
        self.setMouseTracking(True)
        
        self.selected_index = -1
        self.selected_sub_index = -1
        self._scale = 0.0
        self._media_opacity = 1.0
        self._record_angle = 0.0
        
        self.current_volume = self.read_current_volume()
        self.show_volume_hud = False
        
        self.media_pixmap = None
        self.media_title = ""

        self.vol_timer = QTimer(self)
        self.vol_timer.setSingleShot(True)
        self.vol_timer.timeout.connect(self.hide_volume_hud)

        self.hover_scales = []
        self.active_actions = ACTIONS

        self.anim = QPropertyAnimation(self, b"animScale")
        self.anim.setDuration(250)
        self.anim.setEasingCurve(QEasingCurve.Type.OutCubic)

        self.media_fade_anim = QPropertyAnimation(self, b"mediaOpacity")
        self.media_fade_anim.setDuration(180)

        self.hover_timer = QTimer(self)
        self.hover_timer.setInterval(16)
        self.hover_timer.timeout.connect(self.update_hover_animation)

        self.signals.media_loaded.connect(self.on_media_loaded)
        self.signals.handle_click.connect(self.handle_click)

    def get_mediaOpacity(self):
        return self._media_opacity

    def set_mediaOpacity(self, val):
        self._media_opacity = val
        self.update()

    mediaOpacity = pyqtProperty(float, get_mediaOpacity, set_mediaOpacity)

    def on_media_loaded(self, pixmap, title):
        self.media_pixmap = pixmap
        self.media_title = title
        self._media_opacity = 1.0
        self.update()

    def read_current_volume(self):
        if volume_control:
            try:
                vol = volume_control.GetMasterVolumeLevelScalar()
                return int(round(vol * 100))
            except Exception:
                pass
        return 50

    def adjust_volume(self, delta):
        if not self.isVisible():
            return

        cursor_pos = self.mapFromGlobal(QCursor.pos())
        dx = cursor_pos.x() - 300
        dy = cursor_pos.y() - 300
        dist = math.hypot(dx, dy)

        if dist <= 65:
            self.current_volume = max(0, min(100, self.current_volume + delta))
            if volume_control:
                try:
                    volume_control.SetMasterVolumeLevelScalar(self.current_volume / 100.0, None)
                except Exception as e:
                    print(f"Error setting volume: {e}")

            self.show_volume_hud = True
            self.update()
            self.vol_timer.start(1200)

    def hide_volume_hud(self):
        self.show_volume_hud = False
        self.update()

    def get_animScale(self):
        return self._scale

    def set_animScale(self, value):
        self._scale = value
        self.update()

    animScale = pyqtProperty(float, get_animScale, set_animScale)

    def reload_active_actions(self):
        active_exe = get_active_window_exe().lower()
        self.active_actions = []
        
        for act in ACTIONS:
            target = act.get("target_app", "Altijd").lower()
            if target == "altijd" or target == "" or target in active_exe:
                self.active_actions.append(act)

    def load_media_async(self, animate=False):
        def worker():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            pixmap, title = loop.run_until_complete(fetch_media_info_async())
            loop.close()
            self.signals.media_loaded.emit(pixmap, title)

        threading.Thread(target=worker, daemon=True).start()

    def show_at_cursor(self):
        self.reload_active_actions()
        if not self.active_actions:
            self.active_actions = ACTIONS

        self.current_volume = self.read_current_volume()
        self._media_opacity = 1.0
        
        self.load_media_async(animate=False)

        cursor_pos = QCursor.pos()
        self.move(cursor_pos.x() - 300, cursor_pos.y() - 300)
        
        spotify_idx = -1
        for idx, act in enumerate(self.active_actions):
            if act.get("is_spotify", False):
                spotify_idx = idx
                break

        self.selected_index = spotify_idx
        self.selected_sub_index = -1
        
        self.show_volume_hud = False
        self.hover_scales = [0.0] * len(self.active_actions)

        self.show()
        
        self.anim.setStartValue(0.0)
        self.anim.setEndValue(1.0)
        self.anim.start()
        self.hover_timer.start()

    def hide_menu_custom(self):
        self.hover_timer.stop()
        self.vol_timer.stop()
        self.show_volume_hud = False
        self.hide()

    def update_hover_animation(self):
        if not self.isVisible():
            return

        cursor_pos = self.mapFromGlobal(QCursor.pos())
        self.process_mouse_pos(cursor_pos)

        if self.media_pixmap:
            self._record_angle = (self._record_angle + 0.6) % 360

        changed = True 
        for i in range(len(self.hover_scales)):
            target = 1.0 if i == self.selected_index else 0.0
            if abs(self.hover_scales[i] - target) > 0.05:
                self.hover_scales[i] += (target - self.hover_scales[i]) * 0.25
            else:
                self.hover_scales[i] = target

        if changed:
            self.update()

    def process_mouse_pos(self, pos):
        center = QPointF(300, 300)
        dx = pos.x() - center.x()
        dy = pos.y() - center.y()
        dist = math.hypot(dx, dy)

        num_actions = len(self.active_actions)
        if num_actions == 0:
            return

        sector_angle = 360 / num_actions

        spotify_idx = -1
        for idx, act in enumerate(self.active_actions):
            if act.get("is_spotify", False):
                spotify_idx = idx
                break

        self.selected_index = -1
        self.selected_sub_index = -1

        if dist < 60 or dist >= 220:
            return

        angle = math.degrees(math.atan2(dy, dx)) % 360

        if spotify_idx != -1 and 160 <= dist < 210:
            sp_angle = (spotify_idx * sector_angle) % 360
            sp_start = (sp_angle - (sector_angle / 2)) % 360
            sp_end = (sp_angle + (sector_angle / 2)) % 360
            
            in_sp_sector = False
            if sp_start < sp_end:
                in_sp_sector = sp_start <= angle <= sp_end
            else:
                in_sp_sector = angle >= sp_start or angle <= sp_end

            if in_sp_sector:
                self.selected_index = spotify_idx
                angle_diff = (angle - (sp_angle - sector_angle / 2)) % 360
                sub_sec = sector_angle / 3
                self.selected_sub_index = int(angle_diff // sub_sec)
                if self.selected_sub_index > 2:
                    self.selected_sub_index = 2
                return

        if 60 <= dist < 160:
            self.selected_index = int(((angle + (sector_angle / 2)) % 360) // sector_angle)
            if self.selected_index >= num_actions:
                self.selected_index = 0

    def handle_click(self):
        if self.selected_sub_index != -1:
            sub_act = MUSIC_SUB_ACTIONS[self.selected_sub_index]
            execute_media_command(sub_act["cmd"])
            self.load_media_async(animate=True)
        elif self.selected_index != -1 and self.selected_index < len(self.active_actions):
            action = self.active_actions[self.selected_index]
            self.hide_menu_custom()
            self.execute_action(action)
        else:
            self.hide_menu_custom()

    def execute_action(self, action):
        cmd = action.get("cmd", "")
        if not cmd:
            return

        if action["type"] == "app":
            try:
                os.startfile(cmd)
            except Exception:
                try:
                    subprocess.Popen(cmd, shell=True)
                except Exception as e:
                    print(f"Error launching application: {e}")
        elif action["type"] == "key":
            cmd_lower = cmd.lower().strip()

            if "ctrl+c" in cmd_lower:
                keyboard_controller.press(Key.ctrl)
                keyboard_controller.press('c')
                time.sleep(0.01)
                keyboard_controller.release('c')
                keyboard_controller.release(Key.ctrl)
            elif "ctrl+v" in cmd_lower:
                keyboard_controller.press(Key.ctrl)
                keyboard_controller.press('v')
                time.sleep(0.01)
                keyboard_controller.release('v')
                keyboard_controller.release(Key.ctrl)
            else:
                key_to_press = getattr(Key, cmd_lower, None)
                if key_to_press:
                    keyboard_controller.press(key_to_press)
                    keyboard_controller.release(key_to_press)
                else:
                    keys = [k.strip() for k in cmd_lower.split("+")]
                    if len(keys) == 2:
                        mod = Key.ctrl if keys[0] in ["ctrl", "control"] else keys[0]
                        with keyboard_controller.pressed(mod):
                            keyboard_controller.press(keys[1])
                            keyboard_controller.release(keys[1])
                    elif len(keys) == 1:
                        keyboard_controller.press(keys[0])
                        keyboard_controller.release(keys[0])

    def create_sector_path(self, center_x, center_y, inner_r, outer_r, start_angle, angle_span):
        path = QPainterPath()
        path.arcMoveTo(center_x - outer_r, center_y - outer_r, outer_r * 2, outer_r * 2, -start_angle)
        path.arcTo(center_x - outer_r, center_y - outer_r, outer_r * 2, outer_r * 2, -start_angle, -angle_span)
        path.arcTo(center_x - inner_r, center_y - inner_r, inner_r * 2, inner_r * 2, -start_angle - angle_span, angle_span)
        path.closeSubpath()
        return path

    def draw_speaker_icon(self, painter, cx, cy, vol_percent):
        painter.setPen(QPen(QColor(255, 255, 255, 230), 2))
        painter.setBrush(QColor(255, 255, 255, 230))

        speaker_body = QPainterPath()
        speaker_body.moveTo(cx - 8, cy - 4)
        speaker_body.lineTo(cx - 4, cy - 4)
        speaker_body.lineTo(cx + 1, cy - 9)
        speaker_body.lineTo(cx + 1, cy + 9)
        speaker_body.lineTo(cx - 4, cy + 4)
        speaker_body.lineTo(cx - 8, cy + 4)
        speaker_body.closeSubpath()
        painter.drawPath(speaker_body)

        painter.setBrush(Qt.BrushStyle.NoBrush)

        if vol_percent == 0:
            painter.setPen(QPen(QColor(255, 100, 100, 230), 2))
            painter.drawLine(cx + 5, cy - 4, cx + 12, cy + 4)
            painter.drawLine(cx + 5, cy + 4, cx + 12, cy - 4)
        else:
            if vol_percent > 0:
                painter.drawArc(cx - 2, cy - 5, 10, 10, -45 * 16, 90 * 16)
            if vol_percent > 33:
                painter.drawArc(cx + 2, cy - 8, 15, 16, -45 * 16, 90 * 16)
            if vol_percent > 66:
                painter.drawArc(cx + 5, cy - 11, 20, 22, -45 * 16, 90 * 16)

    def paintEvent(self, event):
        if self._scale <= 0 or len(self.active_actions) == 0:
            return

        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        painter.translate(300, 300)
        painter.scale(self._scale, self._scale)
        painter.translate(-300, -300)

        num_actions = len(self.active_actions)
        sector_angle = 360 / num_actions

        for i, act in enumerate(self.active_actions):
            start_angle = (i * sector_angle) - (sector_angle / 2)
            
            hover_val = self.hover_scales[i] if i < len(self.hover_scales) else 0.0
            is_spotify_item = act.get("is_spotify", False)
            
            outer_r = 160 + (8 * hover_val)
            inner_r = 60

            path = self.create_sector_path(300, 300, inner_r, outer_r, start_angle, sector_angle)

            grad = QRadialGradient(300, 300, outer_r)
            if hover_val > 0.05:
                grad.setColorAt(0.3, QColor(0, 102, 204, int(220 * hover_val)))
                grad.setColorAt(1.0, QColor(0, 70, 160, int(240 * hover_val)))
                border_color = QColor(255, 255, 255, 220)
                border_width = 1.8
            else:
                grad.setColorAt(0.0, QColor(20, 23, 30, 120))
                grad.setColorAt(1.0, QColor(10, 12, 16, 140))
                border_color = QColor(255, 255, 255, 50)
                border_width = 1.0

            painter.setBrush(grad)
            painter.setPen(QPen(border_color, border_width))
            painter.drawPath(path)

            mid_angle_rad = math.radians(i * sector_angle)
            icon_r = (160 + inner_r) / 2 if is_spotify_item else (outer_r + inner_r) / 2
            cx = 300 + icon_r * math.cos(mid_angle_rad)
            cy = 300 + icon_r * math.sin(mid_angle_rad)

            if act.get("icon") and os.path.exists(act["icon"]):
                pixmap = QPixmap(act["icon"])
                if not pixmap.isNull():
                    icon_size = 42
                    scaled_pix = pixmap.scaled(icon_size, icon_size, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
                    painter.drawPixmap(int(cx - (icon_size / 2)), int(cy - (icon_size / 2)), scaled_pix)

        spotify_idx = -1
        for idx, act in enumerate(self.active_actions):
            if act.get("is_spotify", False):
                spotify_idx = idx
                break

        if spotify_idx != -1 and (self.selected_index == spotify_idx or self.selected_sub_index != -1):
            sp_start_angle = (spotify_idx * sector_angle) - (sector_angle / 2)
            sub_sector = sector_angle / 3

            sub_inner_r = 160
            sub_outer_r = 205

            for j, sub_act in enumerate(MUSIC_SUB_ACTIONS):
                sub_start = sp_start_angle + (j * sub_sector)
                is_sub_hovered = (self.selected_sub_index == j)
                
                sub_path = self.create_sector_path(300, 300, sub_inner_r, sub_outer_r, sub_start, sub_sector)

                sub_grad = QRadialGradient(300, 300, sub_outer_r)
                if is_sub_hovered:
                    sub_grad.setColorAt(0.3, QColor(0, 150, 100, 210))
                    sub_grad.setColorAt(1.0, QColor(0, 100, 70, 230))
                    sub_border = QColor(255, 255, 255, 220)
                else:
                    sub_grad.setColorAt(0.0, QColor(20, 23, 30, 130))
                    sub_grad.setColorAt(1.0, QColor(10, 12, 16, 150))
                    sub_border = QColor(255, 255, 255, 60)

                painter.setBrush(sub_grad)
                painter.setPen(QPen(sub_border, 1.2))
                painter.drawPath(sub_path)

                mid_sub_rad = math.radians(sub_start + (sub_sector / 2))
                sub_cx = 300 + ((sub_inner_r + sub_outer_r) / 2) * math.cos(mid_sub_rad)
                sub_cy = 300 + ((sub_inner_r + sub_outer_r) / 2) * math.sin(mid_sub_rad)

                painter.setPen(QColor(255, 255, 255, 240))
                painter.setFont(QFont("Segoe UI Symbol", 11, QFont.Weight.Bold))
                painter.drawText(int(sub_cx - 20), int(sub_cy - 15), 40, 30, Qt.AlignmentFlag.AlignCenter, sub_act["label"])

        center_rect = QPainterPath()
        center_rect.addEllipse(236, 236, 128, 128)

        glass_center = QRadialGradient(300, 300, 64)
        glass_center.setColorAt(0, QColor(25, 30, 40, 140))
        glass_center.setColorAt(1, QColor(10, 12, 16, 160))
        
        painter.setBrush(glass_center)
        painter.setPen(QPen(QColor(255, 255, 255, 80), 1.5))
        painter.drawPath(center_rect)

        if self.show_volume_hud:
            self.draw_speaker_icon(painter, 298, 275, self.current_volume)

            painter.setPen(QColor(255, 255, 255, 230))
            painter.setFont(QFont("Segoe UI Variable Display", 11, QFont.Weight.Bold))
            painter.drawText(236, 296, 128, 24, Qt.AlignmentFlag.AlignCenter, f"{self.current_volume}%")

        elif self.media_pixmap or self.media_title:
            painter.setOpacity(self._media_opacity)

            clip_path = QPainterPath()
            clip_path.addEllipse(238, 238, 124, 124)
            painter.setClipPath(clip_path)

            if self.media_pixmap:
                painter.save()
                painter.translate(300, 300)
                painter.rotate(self._record_angle)
                scaled_art = self.media_pixmap.scaled(124, 124, Qt.AspectRatioMode.KeepAspectRatioByExpanding, Qt.TransformationMode.SmoothTransformation)
                painter.drawPixmap(-62, -62, scaled_art)
                painter.restore()
            
            title_grad = QLinearGradient(300, 280, 300, 362)
            title_grad.setColorAt(0, QColor(0, 0, 0, 0))
            title_grad.setColorAt(0.5, QColor(10, 10, 15, 140))
            title_grad.setColorAt(1, QColor(5, 5, 10, 200))

            painter.setBrush(title_grad)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawRect(238, 280, 124, 82)

            painter.setPen(QColor(255, 255, 255, 240))
            painter.setFont(QFont("Segoe UI Semibold", 8))
            painter.drawText(240, 300, 120, 50, Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop, self.media_title)
            
            painter.setOpacity(1.0)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    signals = MenuSignals()
    menu = RadialMenu(signals)
    
    signals.show_menu.connect(menu.show_at_cursor)
    signals.hide_menu.connect(menu.hide_menu_custom)
    signals.change_volume.connect(menu.adjust_volume)

    def on_click(x, y, button, pressed):
        if button == Button.x1 and pressed:
            keyboard_controller.press(Key.f20)
            keyboard_controller.release(Key.f20)
            
        elif button == Button.x2:
            if pressed:
                if menu.isVisible():
                    signals.hide_menu.emit()
                else:
                    signals.show_menu.emit()

        elif button == Button.middle and pressed:
            if menu.isVisible():
                signals.hide_menu.emit()

        elif button == Button.left and pressed:
            if menu.isVisible():
                signals.handle_click.emit()

    def on_scroll(x, y, dx, dy):
        if menu.isVisible():
            delta = 2 if dy > 0 else -2
            signals.change_volume.emit(delta)

    listener = mouse.Listener(on_click=on_click, on_scroll=on_scroll)
    listener.start()

    sys.exit(app.exec())